from flask import Flask
from flask_cors import CORS
from .views.auth.auth import authentication
from .views.movies.movies import movies
from .models import db

def create_app():
    app = Flask(__name__)
    CORS(app)

    app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
    app.config ['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///D:\\Programming\\Projects\\Netflix Clone\\Backend\\db\\netflix.db'
    app.config['SECRET_KEY'] = "you can never guess it"
    app.config['FLASK_ENV'] = 'development'

    db.init_app(app)

    with app.app_context():
        db.create_all()

    app.register_blueprint(authentication)
    app.register_blueprint(movies)

    return app



