
from flask import Blueprint
from ...models import User,db
from flask import request
from sqlalchemy import and_

authentication = Blueprint('authentication', __name__)

@authentication.route('/login/')
def login():
    email = request.args.get('email')
    password = request.args.get('password')
    users=User.query.filter(and_(User.email == email, User.password == password))
    if users.count()==0:
        return "False"
    return "True"