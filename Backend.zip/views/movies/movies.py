import json
from mimetypes import init
from flask import Blueprint, request
import pandas as pd
import requests
import os.path as path
from ...models import db,UserInitialMovieList
import numpy as np

movies = Blueprint('movies', __name__)

filePath=path.abspath(path.join(__file__ ,"../../../"))
baseMovieDataUrl = "https://api.themoviedb.org/3/movie/"
apiKey = "?api_key=6226772a04bd10bedd1ecb7a9c1bb03d&language=en-US"

@movies.route("/movies/most-voted",methods=["GET"])
def getMostVoted():
    movies_df=pd.read_csv(filePath+"\\rs-engine\\most-voted.csv")
    mostvoted_movies=movies_df.head(50)[['id','title']]
    ids=mostvoted_movies.id
    mostvoted_movies.set_index('id',inplace=True)
    
    dic={}
    c=0
    for id in ids:
        try:
            poster_path=requests.get(baseMovieDataUrl+str(id)+apiKey).json()['poster_path']
            if(poster_path!=None):
                dic[id]=[mostvoted_movies.loc[id]['title'],poster_path]
                c+=1
            if c==15:
                break
        except:pass

    return json.dumps(dic)

@movies.route("/movies/popular",methods=["GET"])
def getPopular():    
    movies_df=pd.read_csv(filePath+"\\rs-engine\\popularity.csv")
    movies_df.sort_values("popularity",ascending=False)
    top_15_popular_movies=movies_df.head(15)[['id','title']]

    ids=top_15_popular_movies.id
    top_15_popular_movies.set_index('id',inplace=True)
    
    dic={}
    for id in ids:
        poster_path=requests.get(baseMovieDataUrl+str(id)+apiKey).json()['poster_path']
        dic[id]=[top_15_popular_movies.loc[id]['title'],poster_path]

    return json.dumps(dic)

@movies.route("/movies/get-recommendations/",methods=["GET"])
def recommend():
    uid=request.args.get("id")
    uid=int(uid)
    initial_movies=UserInitialMovieList.query.with_entities(UserInitialMovieList.movie_names).filter_by(user_id=uid).first()
    initial_movies=dict(initial_movies)['movie_names']
    initial_movies=initial_movies.strip('][').split(",")[0]
    df_movies=pd.read_csv(filePath+"\\rs-engine\\movie_titles.csv")
    initial_movies=initial_movies.replace("'","")
    index=df_movies[df_movies.title==initial_movies].index[0]
    
    similarities=np.load(filePath+"\\rs-engine\\similarities_arr.npy")
    cosine_array=similarities[index]
    recommendations=sorted(list(enumerate(cosine_array)),reverse=True,key=lambda x:x[1])[1:20]
    di={}
    c=0
    for i in recommendations:
        try:
            id=df_movies.loc[i[0]].id
            poster_path=requests.get(baseMovieDataUrl+str(id)+apiKey).json()['poster_path']
            if(poster_path!=None):
                di[i[0]]=[df_movies.loc[i[0]].title,poster_path]
                c+=1
                if(c>15):
                    break
        except:print("pass")
    return json.dumps(di)
        

   
