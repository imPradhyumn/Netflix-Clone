import email
from enum import unique
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
   __tablename__ = "users"

   id = db.Column('id', db.Integer, primary_key = True)
   fname = db.Column('fname',db.String(100))
   lname = db.Column('lname',db.String(100))
   email=db.Column('email',db.String(100),unique=True)
   password=db.Column('password',db.String(15))

   def __init__(self,id,fname,lname,email,password):
      self.id=id
      self.fname=fname
      self.lname=lname
      self.email=email
      self.password=password

   def __repr__(self):
      print(self.id,self.fname,self.email)

class UserInitialMovieList(db.Model):
   __tablename__ = "user_initial_movie_list"

   id=db.Column('id', db.Integer, primary_key = True)
   user_id = db.Column('user_id', db.Integer,unique=True)
   movie_names=db.Column("movie_names",db.String)

   def __init__(self,id,uid,names):
      self.id=id
      self.user_id=uid
      self.movie_names=names

   def __repr__(self):
      print(self.user_id,self.movie_ids)


